import adsk.core, adsk.fusion, traceback

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui  = app.userInterface
        design = app.activeProduct

        # Define the path to export
        exportMgr = design.exportManager
        stepOptions = exportMgr.createSTEPExportOptions('C:/Temp/Render-Model.step')  # Local path on the cloud VM
        exportMgr.execute(stepOptions)

        if ui:
            ui.messageBox('STEP file successfully exported.')

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
