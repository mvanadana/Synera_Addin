import adsk.core, adsk.fusion, traceback, os

def run(context):
    try:
        app = adsk.core.Application.get()
        ui  = app.userInterface
        design = adsk.fusion.Design.cast(app.activeProduct)

        exportMgr = design.exportManager
        outputFolder = os.path.expanduser('~/output')  # Forge Design Automation standard

        stepPath = os.path.join(outputFolder, 'RenderedModel.step')
        stepOptions = exportMgr.createSTEPExportOptions(stepPath)
        exportMgr.execute(stepOptions)

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
