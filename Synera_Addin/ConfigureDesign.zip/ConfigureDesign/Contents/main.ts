import { adsk } from "@adsk/fas";

function parametersToObject(parameters: adsk.fusion.ParameterList) {
  let out = {};
  for (let i = 0; i < parameters.count; i++) {
    out[parameters.item(i)!.name] = parameters.item(i)!.expression;
  }
  return out;
}

function run() {
  const scriptParameters = JSON.parse(adsk.parameters || "{}");

  const app = adsk.core.Application.get();
  if (!app) throw Error("No adsk.core.Application.");

  const fileURN = scriptParameters.fileURN;
  if (!fileURN) throw Error("Missing fileURN in parameters.");

  adsk.log(`Opening document: ${fileURN}`);
  const doc = getDocument(app, false, "", fileURN);
  if (!doc) throw Error("Invalid document.");

  const design = doc.products.itemByProductType("DesignProductType") as adsk.fusion.Design;
  if (!design) throw Error("Design product not found.");

  const userParams = design.userParameters;
  // Update user parameters from input
const updateParams = scriptParameters.parameters || {};
for (const name in updateParams) {
  const val = updateParams[name];

  const existingParam = userParams.itemByName(name);
  if (existingParam) {
    adsk.log(`Updating parameter: ${name} = ${val}`);
    existingParam.expression = val;
  } else {
    adsk.log(` Adding parameter: ${name} = ${val}`);
    userParams.add(name, adsk.core.ValueInput.createByString(val), '', '');
  }
}


  const result: Record<string, string> = {};
  for (let i = 0; i < userParams.count; i++) {
    const p = userParams.item(i);
    result[p.name] = p.expression;
  }

  adsk.result = JSON.stringify(result);
  adsk.log(` Fetched Parameters: ${JSON.stringify(result)}`);

  saveDocument(doc, true, "Fetched parameters", doc.dataFile.parentFolder);
  
  // Export the updated design as STEP
const exportMgr = design.exportManager;
const stepOptions = exportMgr.createSTEPExportOptions("Output.step");
if (stepOptions) {
  adsk.log("Exporting document as STEP...");
  if (exportMgr.execute(stepOptions)) {
    adsk.log("STEP export completed.");
  } else {
    adsk.log("STEP export failed.");
  }
} else {
  adsk.log("Failed to create STEP export options.");
}


  while (app.hasActiveJobs) {
    wait(2000);
  }
}


function wait(ms: number) {
  const start = new Date().getTime();
  while (new Date().getTime() - start < ms) adsk.doEvents();
}

function getDocument(
  app: adsk.core.Application,
  useCurrentDocument: boolean,
  hubId: string,
  fileURN: string,
): adsk.core.Document {
  if (useCurrentDocument === true) {
    adsk.log(`Using currently open document: ${app.activeDocument.name}.`);
    return app.activeDocument;
  }

  if (hubId) {
    // Possible hubId formats: base64 encoded string, or business:<id>,
    // or personal:<id> (deprecated)
    const hub =
      app.data.dataHubs.itemById(hubId) ||
      app.data.dataHubs.itemById(`a.${adsk.btoa(`business:${hubId}`, true)}`) ||
      app.data.dataHubs.itemById(`a.${adsk.btoa(`personal:${hubId}`, true)}`);
    if (!hub) throw Error(`Hub with id ${hubId} not found.`);
    adsk.log(`Setting hub: ${hub.name}.`);
    app.data.activeHub = hub;
  }

  const file = app.data.findFileById(fileURN);
  if (!file) throw Error(`File not found ${fileURN}.`);
  let destinationFolder = defaultFolder(
        app,
        "Design Automation for Fusion",
      );
  let newfile = file.copy(destinationFolder);
  newfile.name = 'Nut'
  adsk.log(`Opening ${newfile.name}`);
  const document = app.documents.open(newfile, true);
  if (!document) throw Error(`Cannot open file ${newfile.name}.`);
  return document;
}

function saveDocument(
  doc: adsk.core.Document,
  _saveAsNewDocument: boolean,
  message: string,
  _destinationFolder: adsk.core.DataFolder,
): boolean {
  if (!doc.isModified) {
    adsk.log("Document not modified, not saving.");
    return true;
  }

  adsk.log(`Saving document with message: "${message}".`);
  if (doc.save(message)) {
    adsk.log("Document saved successfully.");
    return true;
  } else {
    adsk.log("Document failed to save.");
    return false;
  }
}


function defaultFolder(app: adsk.core.Application, defaultProjectName: string) {
  const projects = app.data.activeHub.dataProjects;
  if (!projects) throw Error("Unable to get active hub's projects.");
  for (let i = 0; i < projects.count; ++i) {
    const project = projects.item(i)!;
    if (project.name === defaultProjectName) {
      return project.rootFolder;
    }
  }
  adsk.log(`Creating new project: ${defaultProjectName}`);
  const project = projects.add(defaultProjectName);
  if (!project) throw Error("Unable to create new project.");
  return project.rootFolder;
}

run();
